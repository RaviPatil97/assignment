
<?php
if(isset($_POST["submit"]))
{
$host="localhost";
$user="root"; 
$password="root"; 
$dbname='csvDB'; 

$conn=mysql_connect($host,$user,$password) or die (mysql_error());
      mysql_select_db($dbname) or die (mysql_error());
 
echo $filename=$_FILES["file"]["name"];
$ext=substr($filename,strrpos($filename,"."),(strlen($filename)-strrpos($filename,".")));
 
 
 if($ext=="csv")
   {
     $file = fopen($filename, "r");
         while (($data = fgetcsv($file, 10000, ",")) !== FALSE)
         {
            $sql = "INSERT into csvTable(id,name,age,job,country,password) 
					values('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";
            mysql_query($sql);
         }
		 
     fclose($file);
     echo "CSV File has been successfully Imported.";
		 
	 header("Location :file:///C:/Users/kbojjave/Desktop/assignment/display.php");
	}
		 
   }
	else 
	{
	  echo "Error: Please Upload only CSV File";
	}
 
 
?>