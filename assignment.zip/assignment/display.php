
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Import CSV file into Mysql using PHP</h2>
    
    <div id="response" class=" <?php if(!empty($type)) {echo $type . " display-block";} ?> "> <?php if(!empty($message)) { echo $message; } ?> </div>
    <div class="outer-scontainer">

		<?php
            $sqlSelect = "SELECT * FROM csvTable";
            $result = mysqli_query($conn, $sqlSelect);
            
            if (mysqli_num_rows($result) > 0) {
          ?>
            <table id='csvTable'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Job</th>
					<th>Country</th>
					<th>Password</th>
				</tr>
            </thead>
		
		<?php
            while ($row = mysqli_fetch_array($result)) {
         ?>
            <tbody>
                <tr>
                    <td><?php  echo $row['id'];       ?> </td>
                    <td><?php  echo $row['name'];     ?> </td>
                    <td><?php  echo $row['age'];      ?> </td>
                    <td><?php  echo $row['job'];      ?> </td>
					<td><?php  echo $row['country'];  ?> </td>
					<td><?php  echo $row['password']; ?> </td>
                </tr>
    
		<?php  }  ?>
            </tbody>
        </table>
        <?php } ?>
    </div>

</body>

</html>