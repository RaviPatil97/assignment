 
 function update(n)
 {
var name = document.getElementByName("name").value;
var username = document.getElementByName("username").value;
var email = document.getElementByName("email").value;
var country = document.getElementByName("country").value;
var bio = document.getElementByName("bio").value;
var Role = document.getElementByName("role").value;
	 var dataString = '&name=' + name + '&username=' + username + '&email=' + email + '&country=' + country + '&bio=' + bio + '&role=' + role ;
      $.ajax({
      type: "POST",
       url: "update.php",
       data: dataString,
       cache: false,
       success: function(response)
       {
         alert("Record successfully updated");
       }
     });

 }