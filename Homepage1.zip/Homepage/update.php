<?php

$name = $_POST['name'];
$username = $_POST['username'];
$email = $_POST['email'];
$country = $_POST['country'];
$bio = $_POST['bio'];
$role = $_POST['role'];

if (isset($_POST('Username'))) {
	
$username = "root"; 
$password = "root"; 
$database = "website"; 

$mysqli = new mysqli("localhost", $username, $password, $database);
$sql = "UPDATE Details SET Name = '$name',SET Email = '$email',SET Country =' $country',SET Message = '$bio' SET Role = '$role' where Username = '$username' ";
     $result = mysql_query($mysqli,$sql) ;  
    $rows = mysql_fetch_array($result); 
 
 echo "FALSE";
 }




?>