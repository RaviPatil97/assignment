function validate(){
var user=$("#username").val();
var password=$("#password").val();
var role=$("#role").val();

if ( username == '' || password == ''|| role == '') {
alert("Please Fill All Fields");
}
else {
$.ajax({
type: "POST",
url: "check.php",
data: ({username: user,password: password,role: role}),
cache: false,
success: function(response) {
if(role =="admin"){
window.location("http://localhost/homepage/Admin.html");
}
	},
error: function(){
alert("invalid username and password");
}
});
}
return false;
}