function check() {

var name = document.getElementById("name1").value;
var username = document.getElementById("name").value;
var email = document.getElementById("email").value;
var country = document.getElementById("country").value;
var bio = document.getElementById("bio").value;
var Role = document.getElementById("role").value;
var pwd = document.getElementById("password1").value;
var pwd1 = document.getElementById("password2").value;

if (name == '' || username == '' || email == '' || country == '' || bio == '' || role == ''||pwd == ''|| pwd1 == '') {
alert("Please Fill All Fields");
}

else {
var dataString = '&name=' + name + '&username=' + username + '&email=' + email + '&country=' + country + '&bio=' + bio + '&role=' + role +'&password=' + pwd  ;

alert("working");

$.ajax({
type: "POST",
url: "insert1.php",
data: dataString,
cache: false,
success: function(response) {
alert("working1");

window.location("http://localhost/homepage/Homepage.html")
	
}
});
}
}

