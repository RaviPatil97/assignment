<?php

$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];


$username = "root"; 
$password = "root"; 
$database = "website"; 

 
$mysqli = new mysqli("localhost", $username, $password, $database);
$sql= "SELECT * FROM Details WHERE Username = '$username' && Password = '$password' && Role ='$role';

$result = mysqli_query($mysqli,$sql);
$check = mysqli_fetch_array($result);
if(isset($check) && $role == "admin"){
	header("http://localhost/homepage/Admin.html");
}
else{
	header("http://localhost/homepage/Homepage.html");


} 






?>