function checkPwd() {
var pwd1 = document.getElementById("password1").value;
var pwd2 = document.getElementById("password2").value;
if(pwd1!=pwd2)
{
 $('#msg1').html("Password Not Match");
}
else{
 $('#msg1').html("Password Match");
}
}