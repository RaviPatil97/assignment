<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style1.css">

<title>Admin </title>
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src = "update.js"></script>


<script src = "delete.js"></script>
<body>
<div class="container">
  <div><h1>Admin Page</h1></div>
</div>
<?php
 	
$username = "root"; 
$password = "root"; 
$database = "website"; 
 
$mysqli = new mysqli("localhost", $username, $password, $database);

    $sql = "SELECT * FROM `Details`";
    $result = mysql_query($mysqli,$sql) ;
	
    echo "<table border=1>
    <tr>
    <th>Name</th>
    <th>Username</th>
    <th>Email</th>
    <th>Role</th>
	<th>Bio</th>
	<th>Country</th>
    </tr>"; 

    while($row= mysql_fetch_array($result)){
        echo "<tr>";
        echo "<td>" . $record['Name'] . "</td>";
        echo "<td>" . $record['Username'] . "</td>";
        echo "<td>" . $record['Email'] . "</td>";
        echo "<td>" . $record['Role'] . "</td>";
		echo "<td>" . $record['Bio'] . "</td>";
        echo "<td>" . $record['Country'] . "</td>";
		
		echo "<input type="button" id="UPDATE" value="Update" onClick="update($record['Username']);">";
		echo "<input type="button" id="DELETE" value="Delete" onClick="delete($record['Username']);">";
        echo "</tr>";
    }
    echo "</table>";

    mysqli_close();

    ?>
</body>
</html>
