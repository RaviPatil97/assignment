<?php

$name = $_POST['name'];
$username = $_POST['username'];
$email = $_POST['email'];
$country = $_POST['country'];
$bio = $_POST['bio'];
$role = $_POST['role'];
$password = $_POST['password'];


if (isset($username)) {
	
$username = "root"; 
$password = "root"; 
$database = "website"; 

 
$mysqli = new mysqli("localhost", $username, $password, $database);
$sql = "INSERT INTO details (Name,Username,Email,Country,Message,Role,Password) VALUES ('$name','$username','$email' ,'$country' ,'$bio','$role','$password')";
     $result = mysql_query($mysqli,$sql) ;  
    $rows = mysql_fetch_array($result); 
 if(isset($rows)){
 echo "true";
 }

 }

