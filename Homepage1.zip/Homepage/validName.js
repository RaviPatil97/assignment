function checkName() {
var name = document.getElementByName("name").value;
var username = document.getElementByName("username").value;
var email = document.getElementByName("email").value;
var country = document.getElementByName("country").value;
var bio = document.getElementByName("bio").value;
var Role = document.getElementByName("role").value;

var dataString = '&username=' + username  ;


if (name == '' || username == '' || email == '' || country == '' || bio == '' || role == '') {
alert("Please Fill All Fields");
}
else {
$.ajax({
type: "POST",
url: "insert.php",
data: dataString,
cache: false,
success: function(response) {
	
 $('#msg').html(response);

}
});
}
return false;
}