<?php


	
$username = "root"; 
$password = "root"; 
$database = "website"; 
$name = $_POST['username'];

if (isset($name)) {

 $arr = array();

$conn = new mysqli("localhost", $username, $password, $database);
  $sql = "select Username from details ";
    $result = $conn->query($sql); 
    while($row = $result->fetch_assoc()){
            
			  $arr[] = $row["Username"];

        }
}
if (in_array($name, $arr)) {
    echo "Username Already Exist";
}






?>




?>