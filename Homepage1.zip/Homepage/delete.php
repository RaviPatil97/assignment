<?php


$username = $_POST['username'];

if (isset($_POST('Username'))) {
	
$username = "root"; 
$password = "root"; 
$database = "website"; 

$name = $_POST('name'); 
$mysqli = new mysqli("localhost", $username, $password, $database);
$sql = " DELETE FROM Details where Username = $username";
     $result = mysql_query($mysqli,$sql) ;  
    $rows = mysql_fetch_array($result); 
 
 echo "FALSE";
 }




?>