 
 function update(n)
 {
      jQuery.ajax({
      type: "POST",
       url: "update.php",
       data: n=n,
       cache: false,
       success: function(response)
       {
         alert("Record successfully updated");
       }
     });

 }