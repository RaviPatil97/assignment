function validate(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
var admin = document.getElementById("admin").value;
var other = document.getElementById("other").value;



else if(other == "other" && username != "" && password != ""){
var dataString = '&username=' + username + '&password=' + password ;
$.ajax({
type: "POST",
data: dataString,
url: "check.php",
cache: false,
success: function(response) {
	if(response !="Successful")
	window.location = "http://localhost/homepage/Homepage.html";
	else
	alert("Incorrect Username and Password");
}
});
}
}

if ( username == "admin" && password == "admin"  && admin == "admin"){
window.location = "http://localhost/homepage/Admin.php"; // Redirecting to other page.
return false;
}