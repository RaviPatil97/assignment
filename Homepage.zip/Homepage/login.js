function validate(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
var admin = document.getElementByName("role").value;



var dataString = '&username=' + username + '&password=' + password +'&role=' + role;


if (name == '' || username == '' || email == '' || country == '' || bio == '' || role == '') {
alert("Please Fill All Fields");
}
else {
$.ajax({
type: "POST",
url: "check.php",
data: dataString,
cache: false,
success: function(response) {
	
 $('#msg').html(response);

}
});
}
return false;
}