<?php

$name = $_POST['name'];
$name = $_POST['username'];
$email = $_POST['email'];
$country = $_POST['country'];
$bio = $_POST['bio'];
$role = $_POST['role'];

if (isset($_POST('name'))) {
	
$username = "root"; 
$password = "root"; 
$database = "website"; 

$name = $_POST('name'); 
$mysqli = new mysqli("localhost", $username, $password, $database);
  $sql = "select Name from Details ";
    $result = mysql_query($mysqli,$sql) ;  
    $rows = mysql_fetch_array($result); 
    foreach ($rows as $row){
            array_push($arr, $row['Username']);
        }
}
if (in_array($name, $arr)) {
    echo "TRUE";
}
else

 $sql = "INSERT INTO persons (Name,Email,Message,Country) VALUES ('".$name"','".$username"','".$email"', '".$country"', '".$bio"','".$role"')";
 
 echo "FALSE";
 }




?>