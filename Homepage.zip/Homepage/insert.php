<?php

$name = $_POST['name'];
$email = $_POST['email'];
$msg = $_POST['msg'];
$country = $_POST['country'];

if (isset($_POST('name'))) {
	
$username = "root"; 
$password = ""; 
$database = "register"; 

$name = $_POST('name'); 
$mysqli = new mysqli("localhost", $username, $password, $database);
  $sql = "select Name from register ";
    $result = mysql_query($sql) ;  
    $rows = mysql_fetch_array($result); 
    foreach ($rows as $row){
            array_push($arr, $row['Name']);
        }
}
if (in_array($name, $arr)) {
    echo "TRUE";
}
else

 $sql = "INSERT INTO persons (Name,Email,Message,Country) VALUES ('".$name"', '".$email"', '".$msg"','".$country"')";
 
 echo "FALSE";
 }




?>