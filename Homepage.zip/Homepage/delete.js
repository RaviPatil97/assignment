 
 function delete(n)
 {
 var username = document.getElementByName("username").value;
 var data='username='+username
      $.ajax({
      type: "POST",
       url: "delete.php",
       data: data,
       cache: false,
       success: function(response)
       {
         alert("Record successfully updated");
       }
     });

 }