<?php

$username = $_POST['username'];
$password = $_POST['password'];


$username = "root"; 
$password = "root"; 
$database = "website"; 

$name = $_POST('name'); 
$mysqli = new mysqli("localhost", $username, $password, $database);
$sql= "SELECT * FROM Details WHERE username = '$username' AND password = '$password' ";
$result = mysqli_query($mysqli,$sql);
$check = mysqli_fetch_array($result);
if(isset($check)){
echo "Successful";
} 






?>